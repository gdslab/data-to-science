.. _presentations:

********************************************************************************
Presentations
********************************************************************************

- `FOSS4G 2017 <https://vimeo.com/245073446>`__ (`slides <https://s3.amazonaws.com/entwine.io/slides/foss4g2017/index.html#/>`__)
- `FOSS4G 2016 <https://ftp.gwdg.de/pub/misc/openstreetmap/FOSS4G-2016/foss4g-2016-1204-500_billion_points_organizing_point_clouds_as_infrastructure-hd.mp4>`__ (`slides <https://s3.amazonaws.com/entwine.io/slides/foss4g2016/index.html>`__)

