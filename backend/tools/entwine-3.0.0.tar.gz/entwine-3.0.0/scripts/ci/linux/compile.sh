#!/bin/bash

ninja
ninja install
