#!/bin/bash

ninja -v
ninja install
