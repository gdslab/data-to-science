#!/bin/bash

ctest -V
