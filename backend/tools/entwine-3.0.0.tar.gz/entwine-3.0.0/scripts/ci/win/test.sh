#!/bin/bash

ctest -VV --output-on-failure
