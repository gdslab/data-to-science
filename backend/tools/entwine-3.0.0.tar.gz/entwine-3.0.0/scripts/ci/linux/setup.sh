#!/bin/bash

echo "Configuring build type '$BUILD_TYPE'"
mkdir build

gdal-config --version

